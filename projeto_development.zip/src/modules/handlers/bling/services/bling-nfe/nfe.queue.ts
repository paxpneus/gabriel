// src/.../nfe/nfe.queue.ts

import { Job } from "bullmq";
import { BaseQueueService } from "../../../../../shared/utils/base-models/base-queue-service";
import { NFeValidationService } from "./nfe-validation.service";
import { NFeJobData } from "./nfe.types";
import { AxiosInstance } from "axios";
import ordersService from "../../../../sales/orders/order/orders.service";
import { alertService } from "../../../../../shared/providers/mail-provider/nodemailer.alert";

const STATUS = {
  NFE_AGENDADA: 748748,
  CANCELADO: 12,
  AGUARDANDO_VERIFICACAO_HUMANA: 748772
};

const NFE_ERRORS = {
  WRONG_STATUS: {
    id: 4,
    message: "Pedido não está em NFE Agendada ao tentar gerar NFe",
  },
  MISSING_FIELDS: {
    id: 5,
    message: "Campos obrigatórios ausentes para geração de NFe",
  },
  EMISSION_FAILED: { id: 6, message: "Falha ao gerar NFe na Bling" },
};

export class NFeQueue extends BaseQueueService<NFeJobData> {
  private blingApi: AxiosInstance;
  private validationService: NFeValidationService;

  constructor(
    validationService: NFeValidationService,
    blingApi: AxiosInstance,
    options: { workless?: boolean } = {}
  ) {
    super("NFE_EMISSION", {
      concurrency: 1,
      limiter: {
        max: 1,
        duration: 3000
      },
      workless: options.workless
    });
    this.blingApi = blingApi;
    this.validationService = validationService;
  }

  private async markOrderCancelled(
    orderId: number,
    message: string,
  ): Promise<void> {
    const { data } = await this.blingApi.get(`/pedidos/vendas/${orderId}`);

    await this.blingApi.put(`/pedidos/vendas/${orderId}`, {
      ...data.data,
      observacoesInternas: `${data.data.observacoesInternas} \n Pedido marcado como Aguardando verificação humana na geração de nota fiscal: ${message}`
    })
    await this.blingApi.patch(`/pedidos/vendas/${orderId}/situacoes/${STATUS.AGUARDANDO_VERIFICACAO_HUMANA}`, {
      id: STATUS.AGUARDANDO_VERIFICACAO_HUMANA
    })
    const orderSystem = await ordersService.findOne({
      where: {
        id_order_system: orderId
      }
    })
    if (!orderSystem) return;
    await ordersService.update(orderSystem.id, { internal_status: "CANCELLED" });
    console.log(`[NFeQueue] Pedido ${orderId} Marcado como Aguardando verificação humana: ${message}`);
  }

  async process(job: Job<NFeJobData>): Promise<void> {
    const { order_id } = job.data;

    console.log(`[NFeQueue] Processando NFe do pedido ${order_id}`);

    // 1. Busca o pedido fresco na Bling
    const { data } = await this.blingApi.get(`/pedidos/vendas/${order_id}`);
    const order = data.data;

    // 2. Verifica se ainda está em nfe agendada (status 748748)
    if (order.situacao?.id !== STATUS.NFE_AGENDADA) {
      console.log(
        `[NFeQueue] Pedido ${order_id} com status ${order.situacao?.id}, esperado ${STATUS.NFE_AGENDADA}. Abortando.`,
      );
      await this.markOrderCancelled(order_id, NFE_ERRORS.WRONG_STATUS.message);
      return;
    }

    // 3. Valida campos obrigatórios
    const validation = this.validationService.validate(order);

    if (!validation.valid) {
      const detail = validation.missingFields.join(", ");
      console.error(`[NFeQueue] Campos ausentes: ${detail}`);
      await this.markOrderCancelled(
        order_id,
        `${NFE_ERRORS.MISSING_FIELDS.message}: ${detail}`,
      );
      return;
    }

    // 4. Emite a NFe
    try {
      await this.blingApi.post(`/pedidos/vendas/${order_id}/gerar-nfe`)
      console.log(`[NFeQueue] NFe emitida com sucesso para pedido ${order_id}`);

      const internalOrder = await ordersService.findOne({
        where: { id_order_system: String(order.id) },
      });

      if (!internalOrder) {
        console.warn(
          `[NFeQueue] Pedido ${order_id} não encontrado no banco. Pulando update.`,
        );
        return;
      }

      await ordersService.update(internalOrder.id, {
        nfe_emitted: true,
        internal_status: "EMITTED",
      });
    } catch (error: any) {
      console.error(
        `[NFeQueue] Erro ao emitir NFe:`,
        error.response?.data ?? error.message,
      );
      
      // Relança para o BullMQ fazer retry (3x com backoff, herdado da base)
      throw error;
    }
  }

  protected onFailed(job: Job<NFeJobData>, error: Error): void {
    const { order_id } = job.data
    this.markOrderCancelled(order_id, `${NFE_ERRORS.EMISSION_FAILED}`)

  alertService.sendAlert({
    severity: "CRITICAL",
    title: "NFe — falha após todos os retries",
    message: `Pedido ${job.data.order_id} não teve NFe emitida. Requer intervenção manual. Erro: ${error.message}`,
  });
}
}
