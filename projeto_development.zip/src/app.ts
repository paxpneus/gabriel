import express from 'express'
import router from './config/routes'
import 'dotenv/config'
import cors from 'cors'

const app = express()


app.use(cors())
app.use(express.json())
app.use(express.urlencoded({extended: true}))


app.get('/health', (_, res) => res.json({status: 'ok'}))

app.use('/api', router)


export default app